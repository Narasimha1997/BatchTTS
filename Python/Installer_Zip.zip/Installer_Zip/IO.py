import os, platform

def filereader(__FILE_NAME):
    file_=open(__FILE_NAME,"r")
    DATA=file_.read()
    return DATA
    pass
