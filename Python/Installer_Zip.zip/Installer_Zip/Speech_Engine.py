from  gtts import gTTS as Google_TTS
import os, sys, platform, socket
from Python.Installer_Zip import IO
PARSABLE_FILENAME=""

REQUEST_PORT=80
REQUEST_STRING="www.google.com"
REQUEST_TIMEOUT=4

#Check ConnectionError
def check_connections():
    try:
        host=socket.gethostbyname(REQUEST_STRING)
        SEND_SOCKET_REQUEST=socket.create_connection((host, REQUEST_PORT), REQUEST_TIMEOUT)
        return True
    except: False
def gTTS_Speech(PARSABLE_FILENAME, file_name, language):
    Data=IO.filereader(PARSABLE_FILENAME)
    SPEECH=Google_TTS(Data, lang=language)
    SPEECH.save(PARSABLE_FILENAME+".mp3")
    SPEECH_FILE=PARSABLE_FILENAME+".mp3"
    os.renames(SPEECH_FILE,"mp3\\"+file_name+".mp3")
    
    pass
#Checks for the data in Data dir
def gTTS_Core(language):
    count=0
    response=check_connections()
    if response:
        for s in os.listdir("Data"):
           count=count+1
           PARSABLE_FILENAME="Data\\"+s
           print(PARSABLE_FILENAME)
           gTTS_Speech(PARSABLE_FILENAME, s, language)
        if count==0:
           print("No file to parse"); return False
        else:
           print("Parsable file found")
           return True
    else: print("Check for connection")
